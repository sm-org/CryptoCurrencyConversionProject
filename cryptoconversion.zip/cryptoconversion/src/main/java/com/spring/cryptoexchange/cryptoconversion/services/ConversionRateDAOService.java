/**
 * 
 */
package com.spring.cryptoexchange.cryptoconversion.services;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.spring.cryptoexchange.cryptoconversion.entity.ConversionRate;

/**
 * @author SMILETIC
 *
 */
@Repository
@Transactional
public class ConversionRateDAOService {
	@PersistenceContext
	private EntityManager entityManager;
	
	public void insertConversionRate(ConversionRate conversionRate) {
		entityManager.persist(conversionRate);
	}

}
