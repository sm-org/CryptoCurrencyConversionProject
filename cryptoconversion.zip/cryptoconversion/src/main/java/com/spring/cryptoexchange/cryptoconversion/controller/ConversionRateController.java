/**
 * Class that is representing the Controller.
 * Used to manage calls to external APIs to get values and to expose Application end Points.
 * 
 * Class is exposing: 
 * 	/LatestRate
 * 	/HistoricalRates&startDate=vStartDate&endDate=vEndDate
 * 
 * Class is providing the option to get values from the external API
 * 
 */
package com.spring.cryptoexchange.cryptoconversion.controller;

import java.text.ParseException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.spring.cryptoexchange.cryptoconversion.entity.ConversionRate;
import com.spring.cryptoexchange.cryptoconversion.services.ConversionRateService;

/**
 * @author SMILETIC
 *
 */
@RestController
public class ConversionRateController {
	
	@Autowired
	private ConversionRateService service;
	
	@GetMapping("/LatestRate")
	public ConversionRate getLatestRate(){
		return service.getLatestRate();
	}
	
	@GetMapping("/HistoricalRates")
	public List<ConversionRate> getHistoricalnRates(@RequestParam(value = "startDate") String strStartDate,
            @RequestParam(value = "endDate") String strEndDate) throws ParseException{
		return service.getHistoricalnRates(strStartDate, strEndDate);
		
	}
	
	
}