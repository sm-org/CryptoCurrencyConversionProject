/**
 * Class that represent command line runner.
 * This can be used for the testing and verification of the code.
 */
package com.spring.cryptoexchange.cryptoconversion;

import java.time.LocalDateTime;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.spring.cryptoexchange.cryptoconversion.controller.ConversionRateController;
import com.spring.cryptoexchange.cryptoconversion.entity.ConversionRate;
import com.spring.cryptoexchange.cryptoconversion.repositories.ConversionRateRepository;
import com.spring.cryptoexchange.cryptoconversion.schedulers.CryptoConversionScheduler;
import com.spring.cryptoexchange.cryptoconversion.services.ConversionRateService;

/**
 * @author SMILETIC
 *
 */
@Component
public class ConversionRateCmdLineRunner implements CommandLineRunner{
	
	private static final Logger log = LoggerFactory.getLogger(CryptoconversionApplication.class);
	
//	@Autowired
//	private ConversionRateRepository repository;
//	private ConversionRateController crCtr;
	@Autowired
	private ConversionRateService rateService;
	
	
	@Override
	public void run(String... args) throws Exception {
		
//		log.info("********************");
//		ConversionRate rate = new ConversionRate("BTC", "USD", LocalDateTime.parse("2019-06-13T22:25:04.750"), 1500);
//		rateService.insertConversionRate(rate);
//		log.info("Rates found with findAll():" + rateService.getLatestRate());
		
//		repository.save(new ConversionRate("BTC", "USD", LocalDateTime.parse("2019-06-09T06:30:00"), 1500));
//		repository.save(new ConversionRate("BTC", "USD", LocalDateTime.parse("2019-06-08T06:30:00"), 1555));
//		repository.save(new ConversionRate("BTC", "USD", LocalDateTime.parse("2019-06-07T06:30:00"), 1566));
//		repository.save(new ConversionRate("BTC", "USD", LocalDateTime.parse("2019-06-06T06:30:00"), 1512));
//		repository.save(new ConversionRate("BTC", "USD", LocalDateTime.parse("2019-06-05T06:30:00"), 1541));
		
		// fetch all Rates
//		log.info("Rates found with findAll():");
//		log.info("-------------------------------");
//		for (ConversionRate rate : repository.findAll()) {
//			log.info(rate.toString());
//		}
//		log.info("");
		
		// fetch an individual customer by ID
//		repository.findById(3L)
//			.ifPresent(rate -> {
//				log.info("Rate found with findById(1L):");
//				log.info("--------------------------------");
//				log.info(rate.toString());
//				log.info("");
//			});
		
		
		// fetch all Rates
//		log.info("Rates found with Date Period():");
//		log.info("-------------------------------");
//		for (ConversionRate rate : repository.findRatesinDatePeriod(LocalDateTime.parse("2019-06-07T00:00:00"), LocalDateTime.parse("2019-06-09T00:00:00"))) {
//			log.info(rate.toString());
//		}
//		log.info("");
		
//		crCtr = new ConversionRateController();
//		for (int i = 0; i < 10; i++) {
//			crCtr.getRatesExtAPI();
//			
//		}
		
//		CryptoConversionScheduler sch = new CryptoConversionScheduler(repository, crCtr);
//		for (int i = 0; i < 10; i++) {
//			sch.scheduledCryptoConversionFixed();
//			
//		}
		
		
	}

}
