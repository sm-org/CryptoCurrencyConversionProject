/**
 * Class that represent scheduler.
 * Collection of the methods that will represent scheduled jobs.
 */
package com.spring.cryptoexchange.cryptoconversion.schedulers;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.spring.cryptoexchange.cryptoconversion.entity.ConversionRate;
import com.spring.cryptoexchange.cryptoconversion.objects.ConversionRateBTCUSD;
import com.spring.cryptoexchange.cryptoconversion.services.ConversionRateService;
/**
 * @author SMILETIC
 *
 */
@Component
public class CryptoConversionScheduler {

	private final ConversionRateService crService;
	
	public CryptoConversionScheduler(ConversionRateService crService) {
			super();
			this.crService = crService;
		}

	@Scheduled(fixedRateString = "${exchangerate.interval}")
	public void scheduledCryptoConversionFixed() {
		ConversionRateBTCUSD convRateObject = crService.getRatesExtAPI();
		ConversionRate convRateEntity 
			= new ConversionRate(convRateObject.getCode(), "BTC", convRateObject.getRate());
	
		crService.insertConversionRate(convRateEntity);
		
	}
	
}
