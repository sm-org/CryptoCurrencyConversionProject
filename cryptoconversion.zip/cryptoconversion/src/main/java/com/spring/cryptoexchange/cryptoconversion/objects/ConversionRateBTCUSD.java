/**
 * Class that is representing the object of the rates.
 * 
 * Used to hold information in memory until it is stored in the Entity and Database.
 */
package com.spring.cryptoexchange.cryptoconversion.objects;

/**
 * @author SMILETIC
 *
 */
public class ConversionRateBTCUSD{
	private String	code;
	private String	name;
	private	String  rate;
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRate() {
		return rate;
	}
	public void setRate(String rate) {
		this.rate = rate;
	}
	@Override
	public String toString() {
		return "ConversionRateBTCUSD [code=" + code + ", name=" + name + ", rate=" + rate + "]";
	}
	

	
	
	
}
