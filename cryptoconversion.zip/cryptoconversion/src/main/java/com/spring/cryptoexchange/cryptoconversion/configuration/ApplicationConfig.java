/**
 * Class that represents application configuration and where to look for config.
 */
package com.spring.cryptoexchange.cryptoconversion.configuration;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

/**
 * @author SMILETIC
 *
 */
@Configuration
@PropertySource("classpath:config.properties")
public class ApplicationConfig {

}
