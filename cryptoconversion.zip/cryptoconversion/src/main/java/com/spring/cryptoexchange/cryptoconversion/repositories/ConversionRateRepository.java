/**
 * Class that is representing the repository that will manage and handle the values from the database.
 */
package com.spring.cryptoexchange.cryptoconversion.repositories;

import org.springframework.data.jpa.repository.Query;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.spring.cryptoexchange.cryptoconversion.entity.ConversionRate;


/**
 * @author SMILETIC
 *
 */
@Repository
public interface ConversionRateRepository extends CrudRepository<ConversionRate, Long>{
	
	public ConversionRate findTopByOrderByConversionDateDesc();
	
	@Query("SELECT rate FROM ConversionRate rate WHERE rate.conversionDate>=:dateFrom and rate.conversionDate <=:dateTo")
	public List<ConversionRate> findRatesinDatePeriod
			(@Param("dateFrom") LocalDateTime localDateTime, @Param("dateTo") LocalDateTime localDateTime2);

}
