/**
 * 
 */
package com.spring.cryptoexchange.cryptoconversion.services;

import java.time.LocalDateTime;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.spring.cryptoexchange.cryptoconversion.CryptoconversionApplication;
import com.spring.cryptoexchange.cryptoconversion.entity.ConversionRate;
import com.spring.cryptoexchange.cryptoconversion.objects.ConversionRateBTCUSD;
import com.spring.cryptoexchange.cryptoconversion.repositories.ConversionRateRepository;

/**
 * @author SMILETIC
 *
 */
@Service
public class ConversionRateService {

	private static final Logger log = LoggerFactory.getLogger(CryptoconversionApplication.class);
	
	private String  APIURI = "https://bitpay.com/api/rates/USD";
	
	@Autowired
	private ConversionRateRepository repository;
	
	public ConversionRate getLatestRate(){
		ConversionRate cRate = repository.findTopByOrderByConversionDateDesc();
		return cRate;
	}
	
	public List<ConversionRate> getHistoricalnRates(String strStartDate, String strEndDate){
		LocalDateTime startDate = LocalDateTime.parse(strStartDate);
		LocalDateTime endDate = LocalDateTime.parse(strEndDate);
		return repository.findRatesinDatePeriod(startDate, endDate);
		
	}
	
	public ConversionRateBTCUSD getRatesExtAPI(){
		log.info("In getRatesExtAPI");
		log.info("Time: " + LocalDateTime.now());
	    final String uri = APIURI;
	    RestTemplate restTemplate = new RestTemplate();
	    ConversionRateBTCUSD result = restTemplate.getForObject(uri, ConversionRateBTCUSD.class);
		return result;
		
	}
	
	public void insertConversionRate(ConversionRate rate){
		repository.save(rate);
		
	}
}
