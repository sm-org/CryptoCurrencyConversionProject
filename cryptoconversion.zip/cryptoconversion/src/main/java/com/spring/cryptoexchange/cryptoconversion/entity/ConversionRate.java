package com.spring.cryptoexchange.cryptoconversion.entity;
/**
 * Class that represent Entity that will manage the values of the Rates in the Database. 
 */

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * @author SMILETIC
 *
 */
@Entity
public class ConversionRate {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long Id;
	private String	crytpoCurrency;
	private String	currency;
	private LocalDateTime conversionDate;
	private	double rateValue;
	
	public ConversionRate() {
		
	}

	public ConversionRate(String crytpoCurrency, String currency, LocalDateTime conversionDate, double rateValue) {
		super();
		this.crytpoCurrency = crytpoCurrency;
		this.currency = currency;
		this.rateValue = rateValue;
		this.conversionDate = conversionDate;
	}
	
	public ConversionRate(String currency,String crytpoCurrency, String strRateValue) {
		super();
		this.currency = currency;
		this.rateValue = Double.parseDouble(strRateValue);
		this.crytpoCurrency = crytpoCurrency;
		this.conversionDate = LocalDateTime.now();
	}

	public void setCopyConversionRateFields(ConversionRate rate) {
		this.Id = rate.Id;
		this.crytpoCurrency = rate.crytpoCurrency;
		this.currency = rate.currency;
		this.rateValue = rate.rateValue;
		this.conversionDate = rate.conversionDate;
	}
	
	public String getCrytpoCurrency() {
		return crytpoCurrency;
	}

	public void setCrytpoCurrency(String crytpoCurrency) {
		this.crytpoCurrency = crytpoCurrency;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public LocalDateTime getConversionDate() {
		return conversionDate;
	}

	public void setConversionDate(LocalDateTime conversionDate) {
		this.conversionDate = conversionDate;
	}

	public double getRateValue() {
		return rateValue;
	}

	public void setRateValue(double rateValue) {
		this.rateValue = rateValue;
	}

	public long getId() {
		return Id;
	}

	public void setId(long id) {
		Id = id;
	}

	@Override
	public String toString() {
		return String.format("Rate [id=%s, fromCryptoCurrency=%s, toCurrency=%s, conversionDate=%s, rateValue=%s]"
				, this.Id, this.crytpoCurrency, this.crytpoCurrency, this.conversionDate, this.rateValue);
	}
	
	
	@Override
	public boolean equals(Object obj) {
		ConversionRate objRate = (ConversionRate) obj;
		if(this.Id != objRate.Id) {
			return false;
		}
		
		return true;
	}
	

}
