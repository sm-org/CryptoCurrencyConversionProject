/**
 * 
 */
package com.spring.cryptoexchange.cryptoconversion;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.spring.cryptoexchange.cryptoconversion.entity.ConversionRate;
import com.spring.cryptoexchange.cryptoconversion.objects.ConversionRateBTCUSD;
import com.spring.cryptoexchange.cryptoconversion.repositories.ConversionRateRepository;
import com.spring.cryptoexchange.cryptoconversion.services.ConversionRateService;

/**
 * @author SMILETIC
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class ServiceTest {
	
    @Autowired
    private ConversionRateService rateService;

    @MockBean
    private ConversionRateRepository rateRepository;
	
	@Test
	void getLatestRate() {
		ConversionRate rate = new ConversionRate("BTC", "USD", LocalDateTime.parse("2019-06-15T22:25:06.750"), 1501);
		
		when(rateRepository.findTopByOrderByConversionDateDesc()).thenReturn(rate);
		
		ConversionRate rateReturned = rateService.getLatestRate();
		
		assertNotNull(rateReturned);
        assertEquals("failure - dates are not equal", rateReturned.getConversionDate(), rate.getConversionDate());
		
	}
	
	@Test
	void getHistoricalnRates() {
		ConversionRate rate1 = new ConversionRate("BTC", "USD", LocalDateTime.parse("2019-06-15T22:25:06.750"), 1501);
		ConversionRate rate2 = new ConversionRate("BTC", "USD", LocalDateTime.parse("2019-06-13T22:25:06.750"), 1311);
		List<ConversionRate> convRateList = new ArrayList<ConversionRate>();
		convRateList.add(rate1);
		convRateList.add(rate2);
		
		when(rateRepository.findRatesinDatePeriod(LocalDateTime.parse("2019-06-13T22:25:06.750"), LocalDateTime.parse("2019-06-15T22:25:06.750"))).thenReturn(convRateList);
		
		List<ConversionRate> convReturnRateList = rateService.getHistoricalnRates("2019-06-13T22:25:06.750", "2019-06-15T22:25:06.750");
		
		assertNotNull(convReturnRateList);
        assertEquals("failure - Size is not 2", convReturnRateList.size(), 2);
		
	}
	
	@Test
	void getRatesExtAPI() {
		ConversionRateBTCUSD rate = rateService.getRatesExtAPI();//new ConversionRate("BTC", "USD", LocalDateTime.parse("2019-06-15T22:25:06.750"), 1501);

		assertNotNull(rate);
		assertEquals("failure - Code is not BTC", rate.getCode(), "USD");
		
	}
}
