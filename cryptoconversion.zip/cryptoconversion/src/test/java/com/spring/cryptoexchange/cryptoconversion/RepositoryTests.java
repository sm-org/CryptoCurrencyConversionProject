/**
 * 
 */
package com.spring.cryptoexchange.cryptoconversion;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;


import java.time.LocalDateTime;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringRunner;

import com.spring.cryptoexchange.cryptoconversion.entity.ConversionRate;
import com.spring.cryptoexchange.cryptoconversion.repositories.ConversionRateRepository;


@RunWith(SpringRunner.class)
@DataJpaTest
public class RepositoryTests {

	@Autowired    
	private TestEntityManager entityManager; 
	
	@Autowired    
	private ConversionRateRepository rateRepository; 
	
	@Test
	void itShouldSaveRate() {        
		ConversionRate rate = new ConversionRate("BTC", "USD", LocalDateTime.parse("2019-06-15T22:25:06.750"), 1501);             
		rate = entityManager.persistAndFlush(rate);
		
		ConversionRate rate1 = rateRepository.findById(rate.getId()).get();
		
		assertTrue("Fails - should be true", rate.equals(rate1)); 
	}
	
    @Test
    public void findRatesinDatePeriod() {
    	ConversionRate rateF =
                this.entityManager.persist(new ConversionRate("BTC", "USD", LocalDateTime.parse("2019-06-09T22:25:06.750"), 1501));
    	ConversionRate rateS =
                this.entityManager.persist(new ConversionRate("BTC", "USD", LocalDateTime.parse("2019-06-10T22:25:06.750"), 1504));
    	ConversionRate rateT =
                this.entityManager.persist(new ConversionRate("BTC", "USD", LocalDateTime.parse("2019-06-11T22:25:06.750"), 1507));
    	ConversionRate rateFth =
                this.entityManager.persist(new ConversionRate("BTC", "USD", LocalDateTime.parse("2019-06-12T22:25:06.750"), 1521));
    	ConversionRate rateFft =
                this.entityManager.persist(new ConversionRate("BTC", "USD", LocalDateTime.parse("2019-06-13T22:25:06.750"), 1555));

        List<ConversionRate> listsConvRates = rateRepository.findRatesinDatePeriod(LocalDateTime.parse("2019-06-10T00:25:06.750")
        																			, LocalDateTime.parse("2019-06-12T23:25:06.750"));

        //then
        assertNotNull(listsConvRates);
        assertEquals("failure - Size is not 3", listsConvRates.size(), 3);
        assertTrue("Fails - should be true", listsConvRates.contains(rateT)); 
    }	
	

}
